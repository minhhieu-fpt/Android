package com.example.asaimen_demo1;

public class Lop {
    public String Idlop;
    public String TenLop;

    public Lop() {
    }

    public Lop(String idlop, String tenLop) {
        Idlop = idlop;
        TenLop = tenLop;
    }

    public String getIdlop() {
        return Idlop;
    }

    public void setIdlop(String idlop) {
        Idlop = idlop;
    }

    public String getTenLop() {
        return TenLop;
    }

    public void setTenLop(String tenLop) {
        TenLop = tenLop;
    }
}
