package com.example.admin.demomanagentthuchi.Model;

public class information {
    public String title;
    public String content;

    public information(String title, String content) {
        this.title = title;
        this.content = content;
    }
}
