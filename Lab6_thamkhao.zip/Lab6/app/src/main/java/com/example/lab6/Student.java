package com.example.lab6;

public class Student {
    public String id;
    public String ten;
    public String lop;
    public String noiSinh;

    public Student(String id, String ten, String lop, String noiSinh) {
        this.id = id;
        this.ten = ten;
        this.lop = lop;
        this.noiSinh = noiSinh;
    }

    public Student(){}
}
