package com.example.bai_tap_lab6;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class SinhVienAdapter extends BaseAdapter {

    List<SinhVien> lstSinhVien;

    public SinhVienAdapter(List<SinhVien> lstSinhVien) {
        this.lstSinhVien = lstSinhVien;
    }

    @Override
    public int getCount() {
        return lstSinhVien.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row,viewGroup,false);
        TextView tvID = view.findViewById(R.id.tvID);
        TextView tvName = view.findViewById(R.id.tvName);

        SinhVien sv = lstSinhVien.get(i);

        tvID.setText(sv.idSV);
        tvName.setText(sv.tenSV);
        return view;
    }
}
