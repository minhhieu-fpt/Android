package com.example.bai_tap_lab6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    EditText edtID;
    EditText edtTen;
    EditText edtNoiSinh;
    EditText edtNgaySinh;
    EditText edtLop;
    List<SinhVien> lstSv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        edtID = findViewById(R.id.edtID);
        edtTen = findViewById(R.id.edtTen);
        edtNoiSinh = findViewById(R.id.edtNoiSinh);
        edtNgaySinh = findViewById(R.id.edtNgaySinh);
        edtLop = findViewById(R.id.edtLop);

        Intent i = getIntent();
        int index = Integer.parseInt(i.getStringExtra("key_1"));
        lstSv = new ArrayList<>();
        mySQLite mySQLite = new mySQLite(Main2Activity.this);
        lstSv = mySQLite.getListAll();
        SinhVienAdapter sinhVienAdapter = new SinhVienAdapter(lstSv);
        SinhVien sinhVien = new SinhVien();

        edtID.setText(lstSv.get(index).idSV);




    }
}
